# How to install

### Prequisites
- A working Flyff server
- A working Webserver (apache, nginx)

You can then follow the wiki : https://github.com/AzuriomCommunity/Game-Flyff/wiki
# Advanced

 ### Salt for password
 
 You can change the default salt of 'kikugalanet' in your .env for exemple `MD5_HASH_KEY=my-new-salt`
